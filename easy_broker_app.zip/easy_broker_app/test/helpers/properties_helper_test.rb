require 'test_helper'

class PropertiesHelperTest < ActionView::TestCase
end
