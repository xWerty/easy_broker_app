EasyBrokerApp::Application.routes.draw do
  root 'welcome#index'

	get "search/create"
	resources :features 
	resources :kinds

	resources :properties 
	
  
end
