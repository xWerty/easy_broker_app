# Be sure to restart your server when you modify this file.

EasyBrokerApp::Application.config.session_store :cookie_store, key: '_easy_broker_app_session'
