# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
EasyBrokerApp::Application.config.secret_key_base = 'b1a8a004e0cc63cc1224a633556700bddcf43aa10c4c0b615f2ea98de7585d78108d7a4a3f53e2e37d0022d1dec5cce1ac1861923b38e18ff9e8a4864f11989b'
